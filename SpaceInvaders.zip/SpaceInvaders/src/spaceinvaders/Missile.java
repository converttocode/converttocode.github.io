package spaceinvaders;

import javax.swing.*;
import java.awt.*;

public class Missile {
    
    int missilex, missiley, missileWidth, missileHeight;
    Image missile = Toolkit.getDefaultToolkit().getImage("missile.jpg");
    
    public Missile(int x, int y, int width, int height) {
    }
    
    public boolean move(int velx, int vely) {
        return false;
    }
}
