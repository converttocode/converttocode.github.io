package spaceinvaders;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;

/**
 *
 * @author calebweaver
 */
public class SpaceInvaders {

    public static void main(String[] args) {
        Board b = new Board();
        JFrame j = new JFrame();
        
        j.add(b);
        j.setTitle("Space Invaders");
        j.setSize(400, 700);
        j.setResizable(false);
        j.setVisible(true);
        
        Toolkit toolkit =  Toolkit.getDefaultToolkit ();
        Dimension dim = toolkit.getScreenSize();
        j.setLocation(dim.width/2 - j.getWidth()/2 , dim.height/2 - j.getHeight()/2 );
        j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
