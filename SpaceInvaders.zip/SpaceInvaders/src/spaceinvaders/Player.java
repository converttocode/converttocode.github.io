package spaceinvaders;

import javax.swing.*;
import java.awt.*;

public class Player {
    
    int playerx, playery, playerWidth, playerHeight;
    Image rocket = Toolkit.getDefaultToolkit().getImage("rocket.png");
    
    public Player(int x, int y, int width, int height) { }
    
    public void move(int velx, int vely) { }
    
}
