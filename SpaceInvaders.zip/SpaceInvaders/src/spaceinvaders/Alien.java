package spaceinvaders;

import javax.swing.*;
import java.awt.*;

public class Alien {
    
    int alienx, alieny, alienWidth, alienHeight;
    int velx = 3, vely = 0;
    Image alien = Toolkit.getDefaultToolkit().getImage("alien.png");
    
    public Alien(int x, int y, int width, int height) {
    }
    
    public boolean move() {
        return false;
    }
    
}
