package spaceinvaders;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.KeyEvent.*;
import java.util.ArrayList;

public class Board extends JPanel implements ActionListener, KeyListener {
    
    ArrayList<Missile> missiles = new ArrayList<Missile>();
    ArrayList<Alien> aliens = new ArrayList<Alien>();
    
    int velx = 0;
    
    public Board() {
        setBackground(Color.BLACK);
        addKeyListener(this);
        setFocusable(true);
        
        initInvaders();
    }
    
    private void initInvaders() {
        int SPACE = 20;
    }
    
    private void move() { }
    
    private void collisionDetection() { }
    
    private void fireMissile() { }
    
    public void actionPerformed(ActionEvent e) {
        repaint();
    }
    
    public void keyTyped(KeyEvent e) {}
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
    }
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
    }
    
    public void paintComponent(Graphics g) {        
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        
        
    }
}
